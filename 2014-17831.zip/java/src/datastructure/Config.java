package datastructure;

public class Config {
    public final static int MAX_MILEAGE = 72;
    public final static int MAX_MILEAGE_PER_COURSE = 18;
}
